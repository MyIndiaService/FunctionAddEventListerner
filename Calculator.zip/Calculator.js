screen=document.getElementById('screen');
button=document.querySelectorAll('button');
let screenValue = '';
for(items of button)
{
    items.addEventListener('click', (e)=>{
		buttonText = e.target.innerText;
		console.log('Button Text is ', buttonText);
		if(buttonText!='=')
			screen.value +=buttonText;
		else
			screen.value=eval(screen.value);
	});
}
 